public class Test{

    public static void bubbleSort(int[] arr) {
        int n = arr.length;
        boolean swapped; // Optimization: Check if any swaps occurred in a pass

        for (int i = 0; i < n - 1; i++) {
            swapped = false; // Reset swapped flag for each pass

            for (int j = 0; j < n - i - 1; j++) {
                if (arr[j] > arr[j + 1]) {
                    // Swap arr[j] and arr[j+1]
                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                    swapped = true; // Indicate a swap occurred
                }
            }

            // If no two elements were swapped in inner loop, the array is sorted
            if (!swapped) {
                break; // Optimization: Exit early if no swaps happened
            }
        }
    }

    public static void main(String[] args) {
        int[] arr = {5, 1, 4, 2, 8};

        System.out.println("Array before sorting:");
        printArray(arr);

        bubbleSort(arr);

        System.out.println("\nArray after sorting:");
        printArray(arr);
    }

    // Helper function to print the array
    public static void printArray(int[] arr) {
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + " ");
        }
        System.out.println();
    }
}