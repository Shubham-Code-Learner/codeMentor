import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DatabaseUtils {

    // Connection details - fill these with your actual info
    private static final String HOSTNAME = "localhost";
    private static final String INSTANCE_NAME = "DESKTOP-D8ICEE0\\JAVACONNECT"; // e.g., MSSQLSERVER or COMPUTERNAME
    private static final String DATABASE_NAME = "codeMentor";
    private static final String SQL_USER = "sa";
    private static final String SQL_PASSWORD = "admin"; // Replace with actual password

    public static Connection getConnection() throws SQLException, ClassNotFoundException {
        Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        String connectURL = "jdbc:sqlserver://" + HOSTNAME + ":1433"
                + ";instance=" + INSTANCE_NAME
                + ";databaseName=" + DATABASE_NAME
                + ";encrypt=true;trustServerCertificate=true";

        return DriverManager.getConnection(connectURL, SQL_USER, SQL_PASSWORD);
    }

    public static void registerUser(String fullname, String email, String password) {
        String sql = "INSERT INTO Users (fullname, email, password) VALUES (?, ?, ?)";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, fullname);
            stmt.setString(2, email);
            stmt.setString(3, password);

            int rowsInserted = stmt.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("User registered successfully.");
            } else {
                System.out.println("User registration failed.");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static boolean loginUser(String email, String password) {
        String sql = "SELECT fullname FROM Users WHERE email = ? AND password = ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, email);
            stmt.setString(2, password);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    System.out.println("Login successful for: " + rs.getString("fullname"));
                    return true;
                } else {
                    System.out.println("Login failed: Invalid email or password.");
                    return false;
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public static void main(String[] args) {
        // Example registration
        registerUser("John Doe", "john.doe@example.com", "password123");

        // Example login
        boolean loginSuccess = loginUser("john.doe@example.com", "password123");
        if (loginSuccess) {
            System.out.println("Login was successful.");
        } else {
            System.out.println("Login failed.");
        }
    }
}
